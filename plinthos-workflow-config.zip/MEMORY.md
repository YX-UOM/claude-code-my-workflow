# MEMORY.md — Cross-Session Learning Log

> Updated at the end of every session via `/session-wrap`. Never delete entries — only append.

---

## Decision Log

| # | Date | Decision | Rationale | Alternatives Rejected |
|---|------|----------|-----------|----------------------|
| 1 | 2026-02-18 | 5-app Dify architecture (E / S / G / Framework+Risk / Walkthrough) | Modular isolation; working apps stay untouched | Single monolithic workflow — too brittle |
| 2 | 2026-02-18 | Chatflow (not Workflow) for Portfolio Walkthrough (App 5) | Requires multi-turn state management across 33 variables | Static form — can't adapt flow based on responses |
| 3 | 2026-02-18 | Anti-hallucination via explicit gap flagging, never silent fill | Investment-grade reports; fabricated data is a legal/reputational risk | Estimation with disclosure — still too risky for client deliverables |
| 4 | 2026-02-18 | British Land 2022–2025 as quality benchmark | European Sector Leader (GRESB 90/100); publicly available; well-structured | CBRE/JLL generic templates — inconsistent quality |
| 5 | 2026-02-18 | Risk-first positioning (stranded asset exposure > GRESB score) | MEES drives £M losses; more compelling than "nice reports" | ESG score improvement framing — over-promises, under-delivers |
| 6 | 2026-02-18 | 3-tier pricing: £8–10k risk assessment / £15k full report / £40–60k annual | Provides entry point + ladder effect + upsell path | Single £15k price — no entry point for cautious buyers |

---

## Learned Rules

> Rules discovered through corrections or experience. Proposed during session, added here after Sherry confirms.

*(Empty — session 1)*

---

## Open Issues

| # | Issue | Priority | Notes |
|---|-------|----------|-------|
| 1 | G1–G5 workflows not yet complete | 🔴 High | Target: complete before Feb 21 demo |
| 2 | Knowledge Base not yet set up in Dify | 🔴 High | Needs: BL evolution, GRESB guide, MEES guidance, CRREM data |
| 3 | Risk Assessment workflow (App 4) — RED/AMBER/GREEN logic not built | 🔴 High | Blocking: demo narrative |
| 4 | Capex Estimation workflow (App 4) — benchmarks not implemented | 🔴 High | Blocking: Tier 1 product offering |
| 5 | Portfolio Walkthrough (App 5) — full rebuild needed | 🟡 Medium | Target: Feb 15–16 weekend |
| 6 | End-to-end integration test (App 5 → App 4 → Apps 1–3) | 🟡 Medium | Target: Feb 16 |
| 7 | plinthos.org landing page | 🟢 Low | Target: Feb 20–21 |

---

## Validated Insights (Customer Discovery)

> Will be populated after Feb 24 discovery calls begin.

*(Empty — pre-discovery)*

---

## Prompt Performance Log

> Track which LLM node prompts produce best/worst output quality.

| Workflow | Node | Version | Quality (1–10) | Issue | Fix Applied |
|----------|------|---------|----------------|-------|-------------|
| *(empty)* | | | | | |

---

## Session History

| Date | Focus | Key Output | Next Session Priority |
|------|-------|------------|----------------------|
| 2026-02-18 | Workflow configuration setup | 14 config files created | Test against actual Dify workflow build |
