# ADR-001: 5-App Dify Architecture

**Date:** 2026-02-18  
**Status:** Accepted  
**Decided by:** Sherry Xu (founder)

---

## Context

Plinthos requires AI-assisted generation of ESG reports covering Environmental (E1–E4), Social (S1–S4), and Governance (G1–G5) sections, plus a Risk Assessment, Framework Scoring, and a data intake interface. The question was how to organise these into Dify apps/workflows.

## Decision

Organise into **5 Dify apps** with clear separation of concerns:

| App | Type | Scope |
|-----|------|-------|
| 1 | Workflow | Environmental reports (E1–E4) |
| 2 | Workflow | Social reports (S1–S4) |
| 3 | Workflow | Governance reports (G1–G5) |
| 4 | Workflow | Framework Assessment + Risk Assessment + Capex Estimation |
| 5 | **Chatflow** | Portfolio Walkthrough (data intake) |

## Rationale

- **Isolation:** Apps 1 and 2 are working. Isolating them prevents regressions when developing Apps 3–5.
- **Modularity:** Clients can purchase E-only or S-only reports in future; app-level separation makes that possible.
- **Chatflow vs Workflow for App 5:** The Portfolio Walkthrough requires multi-turn conversation, branching logic based on prior answers, and state management across 33 variables — impossible in a single-run Workflow. Chatflow is the only viable choice.
- **App 4 as orchestrator hub:** Combining Framework Assessment, Risk Assessment, and Capex Estimation in one app reduces the number of API calls and keeps related analytical logic co-located.

## Alternatives Rejected

| Alternative | Reason Rejected |
|------------|----------------|
| Single monolithic workflow | Any change risks breaking working E/S sections |
| 13 separate apps (one per section) | Management overhead; no shared state possible |
| Chatflow for all apps | Report generation doesn't need multi-turn; workflow is faster and cheaper |

## Consequences

- Must never modify Apps 1 or 2 without explicit justification
- App 5 → App 4 integration requires a stable JSON contract (see `plinthos-architecture.md`)
- All new ESG sections go into their respective existing apps (not new ones)
