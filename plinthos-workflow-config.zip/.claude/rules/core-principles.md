# Core Principles — Always-On Rules

> These rules apply to every task in every session, regardless of file type or context.

---

## Quality Gate: ESG Report Output

Every generated ESG report section must pass ALL of the following before being presented:

### Gate 1 — Anti-Hallucination
- [ ] Every quantitative figure traces to a collected data input or is explicitly labelled as an industry benchmark with source
- [ ] No figure appears without a unit (`kgCO2e/sqm`, `kWh`, `tCO2e`, `%`, `£M`)
- [ ] Missing data is disclosed with a professional disclosure note, not silently omitted or estimated

### Gate 2 — Regulatory Accuracy
- [ ] Framework references are specific (e.g. "GRESB Performance Component indicator EC1" not "GRESB energy metric")
- [ ] MEES EPC thresholds use current UK government definitions
- [ ] SFDR PAI indicators are numbered correctly if cited

### Gate 3 — Language Quality
- [ ] Tone matches British Land 2022–2025 sustainability accounts (investor-grade, precise, not marketing)
- [ ] No phrases like "we are committed to" without a specific, quantified commitment following
- [ ] Passive voice used sparingly; active claims preferred where data supports them

### Gate 4 — Completeness
- [ ] Section opens with headline performance metric (not narrative context)
- [ ] Year-on-year comparison included if baseline data provided
- [ ] Gap disclosures are grouped at section end, not scattered inline

---

## Decision Principles

**When multiple approaches exist:**
1. State the options with trade-offs (max 3 options)
2. Recommend one with reasoning
3. Note which option is reversible vs architectural

**When uncertain:**
- Ask before assuming on: pricing, client-facing language, regulatory interpretation
- Proceed with best judgement on: code style, file structure, formatting

**When something breaks:**
- Diagnose before fixing — state what broke and why
- Fix the cause, not just the symptom
- Propose a rule to prevent recurrence

---

## Output Naming Conventions

| Output Type | Format | Example |
|------------|--------|---------|
| Dify prompt file | `[app]-[section]-v[n].md` | `e1-energy-v3.md` |
| Sample report | `[fund-name]-[section]-[date].md` | `greenfield-e1-20260218.md` |
| Test result | `qa-[section]-[date].txt` | `qa-e1-20260218.txt` |
| Architecture decision | `ADR-[n]-[topic].md` | `ADR-007-chatflow-vs-workflow.md` |

---

## Version Control Discipline

- Every prompt change gets a new version number (`v1`, `v2`, ...) — never overwrite
- Keep previous versions — regression testing requires them
- Commit message format: `[App1|App2|...|All] brief description`
- Never commit sensitive client data (even sample/test data must be anonymised)

---

## What "Investor-Grade" Means

Investor-grade ESG language has these properties:
- **Specific**: "carbon intensity of 42 kgCO2e/sqm" not "low carbon intensity"
- **Comparative**: "12% below our 2020 baseline" not "improved performance"
- **Verified or disclosed**: "third-party assured by DNV (ISAE 3000)" or "not externally assured — management estimate"
- **Forward-looking with precision**: "targeting EPC A or B across 100% of portfolio by 2030, from current 36%" not "aiming to improve"
- **Structurally complete**: covers what was measured, what wasn't, why, and what's planned
