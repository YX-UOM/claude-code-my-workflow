# Plinthos Architecture Rules
# paths: prompts/**, data/**, docs/architecture/**

> Load when working on Dify workflow design, prompt files, or architecture docs.

---

## 5-App Architecture — Inviolable Constraints

```
App 1: Environmental Reports (E1–E4)   [DO NOT TOUCH — WORKING]
App 2: Social Reports (S1–S4)          [DO NOT TOUCH — WORKING]
App 3: Governance Reports (G1–G5)      [Complete + test only]
App 4: Framework + Risk + Capex        [Active development]
App 5: Portfolio Walkthrough           [Active development — Chatflow]
```

### Data Flow
```
User → App 5 (Chatflow) → Structured JSON payload
                        ↓
              App 4 (Risk Assessment + Framework Score)
                        ↓
         ┌──────────────┼──────────────┐
      App 1 (E)      App 2 (S)      App 3 (G)
         └──────────────┼──────────────┘
                        ↓
              Final Package Assembly
              (Risk Report + Framework + E+S+G)
```

### Integration Contract (App 5 → App 4)

App 5 outputs a JSON payload with this schema. Do not change schema without updating all downstream consumers:

```json
{
  "fund_basics": {
    "name": "string",
    "type": "Fund|REIT|Property Company|JV",
    "aum": "number (GBP)",
    "asset_count": "integer",
    "reporting_period": "string (e.g. FY 2025-26)"
  },
  "frameworks": ["SFDR Article 8", "GRESB", "TCFD", "MEES"],
  "environmental": {
    "assets": [
      {
        "name": "string",
        "type": "Office|Retail|Industrial|Residential|Mixed",
        "location": "string",
        "gia_sqm": "number",
        "epc_rating": "A|B|C|D|E|F|G|null",
        "current_valuation_gbp": "number|null",
        "breeam_rating": "Outstanding|Excellent|Very Good|Good|Pass|null",
        "electricity_kwh": "number|null",
        "gas_kwh": "number|null"
      }
    ],
    "portfolio_totals": {
      "scope1_tco2e": "number|null",
      "scope2_tco2e": "number|null",
      "scope3_tco2e": "number|null",
      "total_energy_kwh": "number|null",
      "water_m3": "number|null",
      "waste_tonnes": "number|null",
      "recycling_rate_pct": "number|null"
    },
    "baseline_year": "integer|null",
    "net_zero_target_year": "integer|null",
    "sbti_status": "Not committed|Committed|Validated|null"
  },
  "social": {},
  "governance": {},
  "gaps": [
    {
      "data_point": "string",
      "affected_assets": ["string"],
      "criticality": "high|medium|low",
      "frameworks_affected": ["string"],
      "recommendation": "string"
    }
  ]
}
```

---

## App 4: Risk Assessment Logic

### RED/AMBER/GREEN Tiering Rules (authoritative)
```python
def tier_asset(epc_rating: str) -> str:
    """
    Returns risk tier based on EPC rating.
    Source: MEES current requirements + anticipated uplift trajectory.
    """
    if epc_rating in ["A", "B"]:
        return "GREEN"
    elif epc_rating == "C":
        return "AMBER"
    elif epc_rating in ["D", "E"]:
        return "RED"
    elif epc_rating in ["F", "G"]:
        return "RED_CRITICAL"  # Currently non-compliant
    else:
        return "UNKNOWN"  # Missing EPC — flag as gap

def quantify_risk(tier: str, valuation_gbp: float) -> dict:
    """
    Returns risk range in GBP.
    Source: RICS/industry estimates — present as indicative, not precise.
    """
    multipliers = {
        "GREEN": (0.0, 0.0),
        "AMBER": (0.05, 0.10),
        "RED": (0.10, 0.25),
        "RED_CRITICAL": (0.20, 0.40),
        "UNKNOWN": (0.0, 0.0)
    }
    low, high = multipliers.get(tier, (0.0, 0.0))
    return {
        "risk_low_gbp": valuation_gbp * low,
        "risk_high_gbp": valuation_gbp * high,
        "note": "Indicative range based on industry benchmarks. Commission independent valuation for decision-making."
    }
```

### Capex Estimation Logic
```python
CAPEX_BENCHMARKS = {
    ("E", "C"): (80, "£/sqm"),
    ("E", "B"): (130, "£/sqm"),
    ("D", "C"): (60, "£/sqm"),
    ("D", "B"): (110, "£/sqm"),
    ("C", "B"): (50, "£/sqm"),
    ("F", "C"): (120, "£/sqm"),
    ("F", "B"): (180, "£/sqm"),
    ("G", "C"): (150, "£/sqm"),
    ("G", "B"): (220, "£/sqm"),
}
UNCERTAINTY = 0.30  # ±30% — always present as range

def estimate_capex(current_epc: str, target_epc: str, gia_sqm: float) -> dict:
    key = (current_epc, target_epc)
    if key not in CAPEX_BENCHMARKS:
        return {"error": f"No benchmark for {current_epc}→{target_epc}"}
    base, unit = CAPEX_BENCHMARKS[key]
    total = base * gia_sqm
    return {
        "estimate_low_gbp": total * (1 - UNCERTAINTY),
        "estimate_high_gbp": total * (1 + UNCERTAINTY),
        "benchmark_per_sqm": base,
        "source": "RICS/industry order-of-magnitude estimate (±30%)"
    }
```

---

## App 5: Portfolio Walkthrough State Machine

### Phase Sequence (Fixed Order)
```
welcome → basics → assets → social → governance → summary
```

### 33 Conversation Variables — Master List
```yaml
# Identity
user_name: string
user_role: string

# Fund Basics  
fund_name: string
entity_type: string
aum: number
asset_count: number
reporting_period: string
primary_geography: string

# Framework Selection
selected_frameworks: JSON string (array)

# Phase Tracking
current_phase: string
phase_completed: JSON string (dict of booleans)

# Environmental Data
assets_data: JSON string (array of asset objects)
energy_data: JSON string (dict keyed by asset name)
certifications_data: JSON string (dict: epcs, breeam)
water_data: JSON string
waste_data: JSON string
scope1_tco2e: number
scope2_tco2e: number
scope3_tco2e: number
baseline_year: number
net_zero_target: string
sbti_status: string
renewable_pct: number

# Social Data
occupancy_rate: number
tenant_satisfaction_score: number
green_lease_pct: number
hs_incidents_total: number
riddor_incidents: number
community_investment_gbp: number
total_employees: number
gender_split_female_pct: number

# Governance Data
board_esg_owner: string
esg_committee_exists: string
esg_in_remuneration: string
policies_uploaded: JSON string (array)
climate_risk_assessed: string
external_assurance: string

# Gap Tracking
identified_gaps: JSON string (array of gap objects)
```

---

## Prompt File Versioning

All Dify LLM node prompts are stored in `prompts/` with this structure:
```
prompts/
├── app1-environmental/
│   ├── e1-energy-v1.md     ← First version
│   ├── e1-energy-v2.md     ← After first improvement
│   └── e1-conversation-manager-v1.md
├── app4-risk/
│   ├── risk-assessment-v1.md
│   └── capex-estimation-v1.md
└── app5-walkthrough/
    ├── conversation-manager-v1.md
    └── gap-report-generator-v1.md
```

Never delete old versions. When testing, compare new version output against prior version using same sample portfolio.
