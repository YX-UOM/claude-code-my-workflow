# ESG Domain Knowledge — Always-On Rules

> These rules prevent domain errors in generated content and code. 
> When in doubt about ESG terminology or regulatory thresholds, flag for Sherry — never guess.

---

## Terminology Standards

Always use these exact terms. Do not paraphrase.

| Use This | Not This |
|----------|----------|
| `carbon intensity (kgCO2e/sqm)` | "carbon per square meter" |
| `like-for-like energy consumption` | "comparable energy" or "same-store energy" |
| `Scope 1, 2 and 3 GHG emissions` | "direct and indirect emissions" |
| `landlord-controlled energy` | "managed energy" |
| `gross internal area (GIA)` | "floor space" or "building size" |
| `EPC rating (A–G)` | "energy certificate" or "efficiency rating" |
| `BREEAM In-Use` | "BREEAM operational" |
| `stranded asset risk` | "obsolescence risk" or "brown discount" |
| `net zero by [year]` | "carbon neutral by [year]" (these are different) |
| `Science Based Targets initiative (SBTi)` | "science-based targets" (lowercase, no acronym) |
| `third-party assured` | "audited" or "verified" (assurance ≠ audit) |
| `GRESB Standing Investments assessment` | "GRESB rating" |
| `EPRA sBPR Gold Award` | "EPRA reporting" |

---

## Regulatory Thresholds (Current — UK)

### MEES (Minimum Energy Efficiency Standards)
- **Current minimum:** EPC E (since April 2018)
- **Proposed uplift:** EPC C by 2027 / EPC B by 2030 (commercial) — consultation ongoing, NOT yet confirmed
- **Language rule:** Always say "proposed" or "anticipated" for post-2025 thresholds — never present them as confirmed law
- **MEES compliance risk:** Any asset EPC F or G is currently non-compliant for new leases
- **2025 position:** EPC E minimum applies to all tenancies (not just new ones)

### GRESB (Real Estate Assessment)
- Scoring: 100-point scale
- **5-star threshold:** Top 20% of peer group (not a fixed score)
- **Performance component:** ~50–60% of total score (energy, GHG, water, waste)
- **Management component:** ~40–50% (policies, certifications, stakeholder engagement)
- **Reporting period:** Annual; submission window April–July; results September
- **Key principle:** Narrative quality has minimal score impact (<5%); underlying data drives score

### SFDR (Sustainable Finance Disclosure Regulation)
- Article 6: No sustainability claim
- Article 8: Promotes environmental/social characteristics (ESG-integrated)
- Article 9: Has sustainable investment as objective (darkest green)
- **PAI indicators:** 18 mandatory + 2 optional for Art. 8/9; property-specific PAIs include energy intensity, GHG intensity, EPC distribution
- **Reporting entity:** Fund/AIFM level, not asset level

### CSRD (Corporate Sustainability Reporting Directive)
- **UK exposure:** UK companies with EU securities or large EU subsidiaries
- **Thresholds for mandatory reporting:** 1,000+ employees AND €450M+ turnover
- **Timeline:** Large public-interest entities from FY2024; others phased to 2028
- **Most mid-market UK funds:** Currently exempt — but institutional LPs increasingly require CSRD-equivalent disclosure

---

## British Land Maturity Model (Reference Benchmark)

| Stage | Score | British Land Year | Key Features |
|-------|-------|------------------|--------------|
| 1: Compliance | 55–69 | Pre-2018 | Absolute emissions only; no assurance |
| 2: Foundation | 70–79 | 2018–2019 | EPRA Gold; limited assurance; 4-star GRESB |
| 3: Integration | 80–89 | 2020 | Intensity metrics; Net Zero commitment; TCFD; 5-star GRESB |
| 4: Leadership | 90–99 | 2021–2022 | SBTi validated; 48-metric assurance; EPC distribution disclosed |
| 5: Sector Leader | 100–120 | 2025 | GRESB 90/100; Development 100/100; whole-life carbon |

Use this model to position client reports ("Your portfolio is currently Stage 2 — here's the path to Stage 3").

---

## ESG Report Structure (Plinthos Standard)

### Environmental (E)
- **E1:** Energy consumption + GHG emissions + intensity metrics + like-for-like
- **E2:** Climate targets + Net Zero pathway + SBTi status + CRREM alignment
- **E3:** EPC distribution + BREEAM coverage + GRESB performance + certifications
- **E4:** Water consumption + waste management + biodiversity + environmental incidents

### Social (S)
- **S1:** Tenant/occupier engagement + green leases + satisfaction surveys
- **S2:** Health, safety & wellbeing + H&S performance + RIDDOR + certifications
- **S3:** Community investment + social value + local employment + S106
- **S4:** Diversity, equity & inclusion + workforce data + pay gap reporting

### Governance (G)
- **G1:** ESG governance structure + Board responsibility + remuneration linkage
- **G2:** Policies & standards inventory + Modern Slavery Statement
- **G3:** Climate risk management + TCFD alignment + scenario analysis
- **G4:** Transparency & disclosure + framework alignment + assurance scope
- **G5:** Supply chain + procurement standards + Living Wage

---

## Risk Assessment Framework (App 4)

### Asset Tiering Logic
```
EPC A or B → GREEN  (low risk; compliant with anticipated MEES B uplift)
EPC C      → AMBER  (medium risk; needs upgrade by 2027–2030 if MEES uplifted)
EPC D or E → RED    (high risk; at stranded asset risk; refinancing risk)
EPC F or G → RED⁺   (critical; currently non-compliant for new leases)
```

### Risk Quantification Benchmarks (cite as "industry benchmark estimates")
- RED assets: 10–25% valuation discount vs green-rated equivalent
- AMBER assets: 5–10% valuation discount risk
- GREEN assets: 3–10% green premium potential

### Capex Estimation Benchmarks (cite as "RICS/industry order-of-magnitude estimates")
| Current → Target | Cost per sqm |
|-----------------|-------------|
| EPC E → C | £80 |
| EPC E → B | £130 |
| EPC D → C | £60 |
| EPC D → B | £110 |
| EPC C → B | £50 |

**Always present as ranges with ±30% uncertainty and recommend professional survey for decision-making.**

---

## Common Domain Errors to Avoid

1. **Net zero ≠ carbon neutral** — net zero eliminates emissions first, then offsets residual; carbon neutral offsets all. Never conflate them.
2. **BREEAM ≠ EPC** — BREEAM is a design/construction certification; EPC is a regulatory energy rating. They measure different things.
3. **GRESB score ≠ star rating** — stars are percentile-based (top 20% = 5 stars); a 90/100 score in a competitive peer group may still be 4 stars.
4. **Scope 2: market-based ≠ location-based** — distinguish these when both are reported (British Land reports both from 2020).
5. **Like-for-like ≠ total** — always specify which boundary is being reported; mixing them is a common disclosure error.
6. **MEES proposed thresholds** — do not present EPC B by 2030 as confirmed law. Use: "under consultation" or "anticipated regulatory direction."
