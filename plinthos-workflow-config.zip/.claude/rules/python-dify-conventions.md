# Python & Dify Conventions — Always-On Rules

---

## Python Standards (Dify Code Nodes)

### Style
- Python 3.10+ syntax; type hints on all function signatures
- `def main(...) -> dict:` — every code node entry point is named `main` and returns a dict
- Import only stdlib (`json`, `re`, `datetime`) — no third-party packages in Dify code nodes
- Max 50 lines per function; extract helpers if longer
- f-strings over `.format()`; no % formatting

### Error Handling Pattern (Mandatory in All Code Nodes)
```python
def main(input_var: str) -> dict:
    try:
        # core logic
        result = process(input_var)
        return {"output": result, "error": ""}
    except ValueError as e:
        return {"output": "", "error": f"Validation error: {e}"}
    except Exception as e:
        return {"output": "", "error": f"Unexpected error: {type(e).__name__}: {e}"}
```

### JSON Handling in Code Nodes
- Always wrap `json.loads()` in try/except — LLM output is not always valid JSON
- Strip markdown fences before parsing:
```python
def extract_json(raw: str) -> dict:
    text = raw.strip()
    if "```json" in text:
        text = text.split("```json")[1].split("```")[0].strip()
    elif "```" in text:
        text = text.split("```")[1].split("```")[0].strip()
    return json.loads(text)
```

---

## Dify Workflow Conventions

### Node Naming
| Node Type | Naming Pattern | Example |
|-----------|---------------|---------|
| LLM node | `[function] LLM` | `Gap Identifier LLM` |
| Code node | `[function] Code` | `State Manager Code` |
| Condition | `Check: [condition]` | `Check: Ready for Report` |
| Answer | `Response: [context]` | `Response: Gap Summary` |
| Variable Assigner | `Set: [variable]` | `Set: current_phase` |
| HTTP Request | `Call: [target]` | `Call: Report Generation API` |

### Conversation Variables (App 5 Chatflow)
- All stored as strings (Dify limitation — serialise dicts/lists as JSON strings)
- Deserialise at start of code nodes, serialise before returning
- Default values must be set — never leave blank (causes silent failures)
- Variable names: `snake_case`, descriptive, no abbreviations except established ones (`aum`, `epc`, `gia`)

### LLM Node Temperature Settings
| Use Case | Temperature |
|----------|------------|
| Report generation (precise language) | 0.2 |
| Conversation manager (natural flow) | 0.3–0.4 |
| Document parsing / data extraction | 0.1–0.2 |
| Gap report generation | 0.2 |

### Model Selection
- Default: `claude-3-5-sonnet` for all production nodes
- Use `claude-3-haiku` only for: simple routing decisions, yes/no conditions
- Never use `claude-3-opus` — cost prohibitive for report generation volume

### Response Format Instruction (Include in Every LLM Node System Prompt)
```
Return your response as valid JSON only. Do not include markdown fences, 
preamble, or explanation outside the JSON object. If you cannot produce 
valid JSON, return: {"error": "reason"}
```

---

## Anti-Hallucination Prompt Pattern

Every report-generating LLM node must include this block verbatim:

```
CRITICAL DATA INTEGRITY RULES:
1. You MUST ONLY use data explicitly provided in the input variables.
2. If a data point is missing or marked as a gap, write a professional 
   disclosure note (e.g., "Water consumption data was not available for 
   this reporting period. This represents a gap the fund intends to 
   address in the next reporting cycle."). 
3. NEVER invent, estimate, or interpolate figures.
4. NEVER use phrases like "approximately", "estimated at", or "around X" 
   unless the input data itself is marked as an estimate.
5. If you are unsure whether data is present, treat it as absent.
```

---

## Dify Knowledge Base Integration

When adding a Knowledge Retrieval node to a workflow:
- Retrieval mode: Semantic Search
- Top K: 5–8 chunks
- Score threshold: 0.7
- Always pass retrieved context to LLM node as `{{knowledge_context}}`
- In LLM prompt, reference it as: "Use the following authoritative context:\n{{knowledge_context}}"

---

## Testing Discipline

Every workflow change requires:
1. **Unit test**: run the changed node in isolation with sample inputs
2. **Integration test**: run the full workflow with a complete sample portfolio
3. **Regression test**: confirm previous output quality is not degraded
4. **Gap test**: test with a portfolio that has deliberate missing data — confirm gaps are flagged, not filled

Sample test portfolios live in `data/sample/`:
- `portfolio_complete.json` — all data present (happy path)
- `portfolio_gaps.json` — 4 critical gaps (anti-hallucination test)
- `portfolio_minimal.json` — minimum viable data (floor quality test)
