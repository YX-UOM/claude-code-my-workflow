# WORKFLOW QUICK REFERENCE — Plinthos

> One page. Read every session. No exceptions.

---

## Modes

| Mode | Trigger | Behaviour |
|------|---------|-----------|
| **Plan** | Any non-trivial task | Present numbered plan, wait for "proceed" |
| **Contractor** | After plan approved | Autonomous execution; check in only for blockers |
| **Review** | Summon `esg-reviewer` agent | Adversarial critique of report output |
| **Prompt-Eng** | Summon `prompt-engineer` agent | Optimise a Dify LLM node prompt |
| **QA** | Summon `qa-tester` agent | Test anti-hallucination and gap detection |

---

## Non-Negotiables (Cannot Be Overridden)

1. **Never modify Apps 1 or 2** unless Sherry explicitly says so  
2. **Never fabricate data** — flag gaps professionally, always  
3. **Always cite benchmarks** — capex estimates and risk % must have a source  
4. **Quality bar = British Land 2022–2025** — investor-grade, not educational  
5. **Plan before building** — no multi-file tasks without an approved plan  

---

## Task Complexity Heuristic

| Complexity | Rule |
|-----------|------|
| **Trivial** (1 file, clear spec) | Execute directly |
| **Simple** (2–3 files, known pattern) | Quick plan (3–5 bullets), proceed |
| **Standard** (new feature, cross-app) | Full plan with numbered steps, wait for approval |
| **Architectural** (changes data flow or app structure) | Plan + risk assessment + alternatives considered |

---

## Slash Commands

| Command | What It Does |
|---------|-------------|
| `/new-workflow [name]` | Scaffold a new Dify workflow with standard structure |
| `/test-report [section]` | Run end-to-end quality check on a report section |
| `/session-wrap` | Log learnings, update MEMORY.md, generate handoff |

---

## Agent Roster

| Agent | Summon When |
|-------|------------|
| `@planner` | Task is complex — need atomic step decomposition |
| `@esg-reviewer` | ESG report section is drafted — need adversarial check |
| `@prompt-engineer` | Dify LLM node prompt needs optimisation |
| `@qa-tester` | Testing anti-hallucination or gap detection behaviour |

---

## Key File Locations

```
CLAUDE.md           → Master context (read first)
MEMORY.md           → Decisions + learnings (check before starting)
prompts/            → Versioned Dify node prompts
data/sample/        → Test portfolios for QA runs
docs/architecture/  → ADRs and design diagrams
```

---

## Critical Timeline

```
Feb 21  → Demo ready (hard deadline)
Feb 24  → Customer discovery begins (35-day window)
Mar 30  → 1 paying pilot (make-or-break milestone)
Mar 31  → Sherry in China (limited availability)
Apr–Jul → GRESB season (primary revenue window)
```

---

## Correction Protocol

When Sherry corrects a mistake:
1. Acknowledge the correction specifically
2. Fix the immediate issue
3. Propose a rule: "To prevent recurrence: [rule]"
4. After Sherry confirms → add to relevant `.claude/rules/` file AND `MEMORY.md ## Learned Rules`
