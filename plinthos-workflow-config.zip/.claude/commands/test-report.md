# /test-report [section] [version]

## What This Does
Runs a complete quality gate check on a generated ESG report section.
Combines `@qa-tester` (data integrity) and `@esg-reviewer` (language quality).

## Usage
```
/test-report e1           ← Tests latest version of E1 prompt
/test-report e1 v3        ← Tests specific version
/test-report risk-assessment
/test-report all          ← Tests all sections sequentially
```

## Execution Steps

When invoked, do the following:

### 1. Load Test Portfolio
Load `data/sample/portfolio_gaps.json` (Portfolio B) as primary test.
This is the critical test — if a section passes with missing data, it passes.

### 2. Simulate the Dify Workflow
Run the section's LLM prompt against the test portfolio:
- Read the prompt from `prompts/[app]-[category]/[section]-v[N].md`
- Construct the input as the prompt specifies
- Generate output using the prompt (you ARE the LLM in this simulation)

### 3. Run QA Battery
Apply the `@qa-tester` checklist against the generated output:

**Check A — No Hallucination**
For every number in the output:
- Trace it to an input variable in Portfolio B
- If traceable → PASS
- If not traceable → FAIL + quote the offending text

**Check B — Gap Disclosure**
For every null field in Portfolio B:
- Find where this would appear in the section
- Confirm a disclosure note exists → PASS
- If absent or silently omitted → FAIL

**Check C — Units**
For every quantitative figure:
- Confirm unit appears immediately after → PASS
- If no unit → FAIL

**Check D — JSON Validity** (if applicable)
- Attempt `json.loads()` on any JSON-formatted output
- PASS or FAIL

### 4. Run Language Review
Apply `@esg-reviewer` Tier 1 and Tier 2 checks against the output.

### 5. Output Test Report
```markdown
# /test-report: [section] v[N] — [date]

## Quick Verdict
**Anti-hallucination:** [PASS / FAIL]
**Gap disclosure:** [PASS / FAIL]
**Unit completeness:** [PASS / FAIL]
**Language quality:** [PASS / FLAG / FAIL]
**Overall:** [READY / NEEDS FIXES / BLOCKED]

## Issues Found
[List of FAIL items with quotes and fixes]

## Flags (Non-Blocking)
[List of FLAG items with suggestions]

## Sample Output (Abridged)
[First 150 words of the generated section]

## Next Action
[Specific instruction: "Update prompt line 34 to..." or "Ready for demo"]
```

### 6. Update MEMORY.md
Add entry to `## Prompt Performance Log`:
```
| [section] | [Node] | v[N] | [quality 1–10] | [Issue summary] | [Fix applied] |
```

## Quality Gate Thresholds

| Gate | Threshold | Action if Failed |
|------|-----------|-----------------|
| Anti-hallucination | 0 fabrications | Must fix before any use |
| Gap disclosure | 100% coverage | Must fix before any use |
| Unit completeness | 100% | Must fix before demo |
| JSON validity | 100% | Must fix before integration |
| Language quality | 7/10 minimum | Fix before client delivery |
