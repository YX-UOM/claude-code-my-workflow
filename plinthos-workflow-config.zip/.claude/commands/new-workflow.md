# /new-workflow [name] [app-number]

## What This Does
Scaffolds a new Dify workflow with the Plinthos standard structure: 
prompt file, test plan, and architecture documentation stub.

## Usage
```
/new-workflow risk-assessment 4
/new-workflow capex-estimation 4
/new-workflow g3-climate-risk 3
```

## Execution Steps

When invoked, do the following autonomously:

### 1. Create Prompt File
Create `prompts/app[N]-[category]/[name]-v1.md` with this template:

```markdown
# Prompt: App[N] — [Name] v1
**Created:** [date]
**Model:** claude-3-5-sonnet
**Temperature:** [0.1–0.4 based on use case]
**Max tokens:** [appropriate value]

## System Prompt

### Role
[2–3 sentence role definition]

### Input Variables
[List all Dify input variables with types]

### Task
[Numbered, atomic steps]

### DATA INTEGRITY RULES — NON-NEGOTIABLE
1. Use ONLY data explicitly present in the input variables.
2. If a data point is missing, write a professional disclosure note.
3. Never invent, estimate, or interpolate figures.
4. Never use "approximately", "around", or "estimated at" unless 
   the input itself is labelled as an estimate.
5. Treat any data point not in input_variables as absent.

### Output Format
[JSON schema or markdown template]

## Test Cases

### Test 1 — Happy Path
Input: [compact JSON]
Expected: [description of correct output]

### Test 2 — Gap Case  
Input: [JSON with critical nulls]
Expected: [disclosure notes, no fabrication]
```

### 2. Create Test Plan Stub
Create `data/tests/[name]-test-plan.md`:

```markdown
# Test Plan: [Name]

## Test Portfolios
- [ ] Portfolio A (complete) — see `data/sample/portfolio_complete.json`
- [ ] Portfolio B (gaps) — see `data/sample/portfolio_gaps.json`  
- [ ] Portfolio C (minimal) — see `data/sample/portfolio_minimal.json`

## Expected Outputs
[Fill in before running tests]

## Test Results Log
| Date | Version | Portfolio | Result | Notes |
|------|---------|-----------|--------|-------|
```

### 3. Update MEMORY.md
Add entry to `## Open Issues`:
```
| [N+1] | [name] workflow — prompt v1 created, needs testing | 🟡 Medium | Scaffolded [date] |
```

### 4. Report to Sherry
Output a summary:
```
✅ Scaffolded: [name]
📁 Prompt file: prompts/app[N]-[category]/[name]-v1.md
📋 Test plan: data/tests/[name]-test-plan.md
📝 MEMORY.md updated

Next step: Fill in the system prompt, then run /test-report [name]
```
