# /session-wrap

## What This Does
Closes out a working session: logs what was learned, updates MEMORY.md,
flags open issues, and generates a handoff summary for the next session.

## Usage
```
/session-wrap
```

Run this at the end of every working session, or when switching focus areas.

## Execution Steps

### 1. Summarise Session Work
List everything that was created, modified, or decided this session:
- Files created/modified
- Workflows built or updated
- Prompts written or revised
- Decisions made
- Issues resolved

### 2. Update MEMORY.md

**Add to `## Session History`:**
```
| [date] | [1-line focus] | [key output] | [next session priority] |
```

**Add to `## Decision Log`** (any new architectural or design decisions):
```
| [N] | [date] | [decision] | [rationale] | [alternatives rejected] |
```

**Add to `## Learned Rules`** (any corrections from Sherry):
```
| [date] | [rule learned] | [triggered by] |
```

**Update `## Open Issues`**:
- Mark resolved issues as ~~strikethrough~~ or remove
- Add any newly discovered issues
- Update priority on existing issues if changed

### 3. Update Prompt Performance Log
If any prompts were tested this session, update `## Prompt Performance Log` with results.

### 4. Check Timeline
Check current date against critical milestones:
```
Feb 21  → Demo ready
Feb 24  → Customer discovery begins
Mar 30  → 1 paying pilot
```

Flag if any milestone is at risk based on current progress.

### 5. Generate Handoff Note

Output this to the screen (not saved to file — it's for Sherry to read):

```markdown
## Session Wrap — [date]

### What We Did
[Bullet list of completed work]

### State of Play
- App 1 (E): [status]
- App 2 (S): [status]
- App 3 (G): [status]
- App 4 (Risk/Framework): [status]
- App 5 (Walkthrough): [status]

### Open Issues (Top 3)
1. [Most critical issue]
2. [Second]
3. [Third]

### Proposed Priority for Next Session
[What to work on first next time, and why]

### Timeline Check
[Are we on track for Feb 21 demo? Any risks?]

### Notes for Sherry
[Anything that needs a decision before next session can proceed]
```

### 6. Proposed Rules (If Applicable)
If Sherry corrected anything this session, propose rules for MEMORY.md:

```
## Proposed Learned Rules
[Rule N]: "[Rule text]"
Triggered by: [what error/correction led to this]
Confirm to add to .claude/rules/[relevant file]
```
