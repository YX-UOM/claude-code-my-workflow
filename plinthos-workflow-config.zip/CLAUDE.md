# CLAUDE.md — Plinthos Project Context

> Read this file completely at the start of every session before taking any action.

---

## Project Identity

**Product:** Plinthos — AI-powered ESG report writing service for UK real estate funds  
**Stage:** Pre-revenue MVP · Demo target: Feb 21 2026 · First paying pilot: Mar 30 2026  
**Founder:** Sherry Xu · University of Manchester spin-out (Dept. Planning, Property & Environmental Management)  
**Stack:** Dify (cloud) · Claude API (claude-3-5-sonnet) · Python · GitHub  
**Domain:** UK real estate ESG compliance — SFDR · GRESB · TCFD · MEES · CSRD · EU Taxonomy

---

## Core Mission (One Sentence)

Plinthos solves the **"last mile" problem** in ESG reporting: transforming validated building data into investor-ready compliance narratives that data platforms (Measurabl, Deepki, CRREM) don't produce.

---

## 5-App Architecture (Never Reorganise Without Explicit Instruction)

| App | Type | Purpose | Status |
|-----|------|---------|--------|
| **App 1** | Dify Workflow | Environmental Reports (E1–E4) | ✅ Working |
| **App 2** | Dify Workflow | Social Reports (S1–S4) | ✅ Working |
| **App 3** | Dify Workflow | Governance Reports (G1–G5) | 🔧 In progress |
| **App 4** | Dify Workflow | Framework Assessment + Risk Assessment + Capex Estimation | 🔧 Active development |
| **App 5** | Dify Chatflow | Portfolio Walkthrough (data intake) | 🔧 Active development |

**Golden rule:** Apps 1 and 2 are working. Do NOT touch them unless Sherry explicitly instructs it.

---

## Quality Standard

Every ESG report section must match **British Land 2022–2025 Sustainability Accounts** in:
- Professional investor-grade language (not educational, not generic)
- Quantitative precision: always `kgCO2e/sqm`, `kWh/sqm`, `tCO2e`, `£M`
- Explicit regulatory alignment (cite GRESB question numbers, SFDR PAI indicators, MEES band thresholds)
- Gap disclosure: flag missing data transparently — NEVER fabricate or estimate without labelling

---

## Anti-Hallucination Architecture (Non-Negotiable)

This is the most critical technical principle. Every LLM node in every Dify workflow must:

```
IF data_point IN collected_data → USE exact value
IF data_point IN gap_report.missing → WRITE disclosure note, never invent
IF data_point unexpected → FLAG, do not generate
```

Any prompt you write must include explicit instructions prohibiting fabrication. If data is absent, the output says so professionally — it never silently fills gaps.

---

## Working Agreements

- **Plan first, always.** For any task touching more than one file or one Dify node, produce a plan and wait for approval before executing.
- **Contractor mode after approval.** Once plan is approved, work autonomously. Only return for genuine decision points or blockers — not routine choices.
- **Decision log.** Every significant architectural or design decision gets logged in `MEMORY.md` under `## Decision Log`.
- **Correction learning.** When Sherry corrects something, propose a rule to prevent recurrence. Add it to the relevant `.claude/rules/` file after confirmation.
- **No magic numbers.** Capex estimates, risk percentages, and financial figures must cite their source (CRREM, industry benchmark, specific regulation). Never invent benchmark values.
- **Output files go to `/mnt/user-data/outputs/`.** Intermediate work lives in `/home/claude/`.

---

## Regulatory Reference (Quick Lookup)

| Framework | Key Requirement | Priority for Plinthos |
|-----------|----------------|----------------------|
| **MEES** | EPC E minimum now; B by ~2030–2035 | 🔴 Critical — drives stranded asset risk |
| **GRESB** | Annual benchmark; 50–60% performance, 40–50% management | 🔴 Critical — primary client use case |
| **SFDR Art. 8/9** | PAI indicators mandatory; Scope 1+2+3 required | 🟡 Important — EU-exposed funds |
| **TCFD** | Climate risk disclosure; scenario analysis | 🟡 Important — UK listed entities |
| **CSRD/ESRS** | €50–80k+ penalties; most mid-market funds exempt until 2026–28 | 🟢 Emerging |
| **EU Taxonomy** | DNSH criteria; technical screening | 🟢 Emerging |

---

## Session Startup Checklist

Before starting any task:
1. Read `MEMORY.md` — check Decision Log and open issues
2. Read `.claude/WORKFLOW_QUICK_REF.md` — confirm mode and constraints
3. Confirm which App(s) are in scope
4. If task is non-trivial → enter plan mode, present plan, wait for approval

---

## File Map

```
/
├── CLAUDE.md                          ← You are here
├── MEMORY.md                          ← Cross-session learning
├── .claude/
│   ├── WORKFLOW_QUICK_REF.md          ← Operating manual
│   ├── rules/
│   │   ├── core-principles.md         ← Always-on: quality gates
│   │   ├── python-dify-conventions.md ← Always-on: code standards
│   │   ├── esg-domain-knowledge.md    ← Always-on: domain context
│   │   └── plinthos-architecture.md   ← Path-scoped: architecture rules
│   ├── agents/
│   │   ├── planner.md                 ← Task decomposition specialist
│   │   ├── esg-reviewer.md            ← Adversarial ESG output reviewer
│   │   ├── prompt-engineer.md         ← Dify LLM node prompt specialist
│   │   └── qa-tester.md               ← Anti-hallucination & gap detection tester
│   └── commands/
│       ├── new-workflow.md            ← /new-workflow slash command
│       ├── test-report.md             ← /test-report slash command
│       └── session-wrap.md            ← /session-wrap slash command
├── prompts/                           ← Versioned Dify LLM node prompts
├── data/                              ← Sample portfolios for testing
├── docs/                              ← Architecture decisions, research
└── outputs/                           ← Generated sample reports
```
